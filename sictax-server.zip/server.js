require('dotenv').config();
const express = require('express');
const { Client } = require('pg');
const cors = require('cors');
const bcrypt = require('bcryptjs');

const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET;
const app = express();
app.use(cors());
app.use(express.json());

// Configuración de la base de datos PostgreSQL
const client = new Client({
    user: process.env.DB_USER,
    host:  process.env.DB_HOST,
    database:  process.env.DB_DATABASE,
    password:  process.env.DB_PASSWORD,
    port:  process.env.DB_PORT,
});

// Conectar a PostgreSQL
client.connect()
    .then(() => console.log("Conectado a PostgreSQL"))
    .catch(err => console.error('Error al conectar', err.stack));


// Middleware para verificar el JWT
const authenticateToken = (req, res, next) => {
    // El token puede venir en los headers como 'Authorization: Bearer <token>'
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Obtenemos el token

    if (!token) {
        return res.status(401).json({ message: 'Acceso denegado. No se ha proporcionado un token' });
    }

    // Verificar el token
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Token no válido o expirado' });
        }

        // Guardar la información del usuario extraída del token en req.user
        req.user = user;
        next(); // Continuar con la siguiente función en la ruta
    });
};

///API

// Endpoint para obtener datos
app.get('/datos', async (req, res) => {
    try {
        const result = await client.query('SELECT * FROM sictax_tramitesdb.asignacion');
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).send('Error en la consulta a la base de datos');
    }
});



//Endpoint Ruta de login
app.post('/login', async (req, res) => {
    const { login_name, password } = req.body;

    try {
        // Buscar al usuario en la base de datos
        const result = await client.query('SELECT password,login_name, idusuario, primer_nombre, primer_apellido, correo_electronico, hashverificacionusuario, cargo FROM sictax_control_usuario.usuario WHERE login_name = $1', [login_name]);
        
        if (result.rows.length === 0) {
            return res.status(400).json({ success: false, message: 'Usuario no encontrado' });
        }
        const user = result.rows[0];
        const hashedPassword = result.rows[0].password;

        // Comparar la contraseña ingresada con el hash almacenado
        const isMatch = await bcrypt.compare(password, hashedPassword);

        if (isMatch) {

             // Si la contraseña es correcta, generar el JWT
             const token = jwt.sign(
                { login_name: user.login_name, primer_nombre: user.primer_nombre, cargo: user.cargo }, // Payload
                JWT_SECRET,  // Clave secreta para firmar el token
                { expiresIn: '1d' } // El token expirará en 1 hora
            );


            return res.json({
                success: true,
                message: 'Login exitoso',
                token: token,
                user: {
                    
                    primer_nombre: user.primer_nombre,
                    idusuario:user.idusuario,
                    primer_apellido: user.primer_apellido,
                    correo_electronico: user.correo_electronico,
                    hashverificacionusuario: user.hashverificacionusuario,
                    cargo: user.cargo
                }
            });
        } else {
            return res.status(400).json({ success: false, message: 'Contraseña incorrecta' });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Error del servidor' });
    }
});



// // Rutas protegidas con el middleware authenticateToken
app.post('/datosasignados', authenticateToken, async (req, res) => {
    const { usuarioasignado } = req.body;
   
    let query = `
    SELECT t.*, e.nombre as etapa, p.*,d.dispname as departamentoname, m.dispname as municipioname 
    FROM sictax_tramitesdb.asignacion t
    INNER JOIN sictax_tramitesdb.etapas e ON t.etapa_id = e.id
    INNER JOIN sictax_data_temporal.lc_predio_t p ON t.idpredio = p.idpredio
    INNER JOIN sictax_dominios.st_departamentos d ON p.departamento = d.itfcode::text
    INNER JOIN sictax_dominios.st_municipios m ON p.municipio = m.itfcode::text
    WHERE t.etapa_id = 13
`;

let queryParams = [];

if (usuarioasignado) {
    query += " AND t.usuario_asignado = $1";
    queryParams.push(parseInt(usuarioasignado, 10));
}

    try {
        const result = await client.query(query, queryParams);
        if (result.rows.length > 0) {
            return res.json({
                success: true,
                message: 'Datos encontrados',
                datos: result.rows
            });
        } else {
            return res.status(400).json({
                success: false,
                message: 'No se encontraron datos',
                datos: []
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).send('Error en la consulta a la base de datos');
    }
});

// // Otra ruta protegida
// app.get('/perfil', authenticateToken, (req, res) => {
//     res.json({ message: `Hola, ${req.user.primer_nombre}. Este es tu perfil.` });
// });





// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
